import json
import os.path
from os import path

seasons = ["SUMMER", "AUTUMN", "WINTER", "SPRING"]

def create_faction():
    faction = {
        "factionName": "",
        "satisfaction": 0,
        "supporter": 0
    }

    print("\n------ Rajouter une faction ------")
    faction["factionName"] = input("\nNom de faction : ").upper()

    faction["satisfaction"] = prevent_int("\nSatisfaction de base : ")
    while not (0 < faction["satisfaction"]):
        faction["satisfaction"] = prevent_int("\tMauvaise réponse\nSatisfaction de base : ")

    faction["supporter"] = prevent_int("\nNombre de partisans de base : ")
    while not (0 < faction["supporter"]):
        faction["supporter"] = prevent_int("\tMauvaise réponse\nNombre de partisans de base : ")
    
    return dict(faction)

def choose_season():
    print("\n~ Choix saisons ------")
    choice = 1
    seasons_chosen = []
    while choice != 0:
        print("\nSaisons actuelles : ", seasons_chosen)
        print("Choisissez une saison :")
        for i in range(len(seasons)):
            print("\t" + str(i + 1) + ". " + seasons[i])
        choice_season = prevent_int("Réponse : ")
        while not (0 <= choice_season < len(seasons) + 1):
            choice_season = prevent_int("\tMauvaise réponse\nRéponse : ")
        if choice_season == 0:
            break
        if seasons[choice_season - 1] in seasons_chosen:
            seasons_chosen.remove(seasons[choice_season - 1])
        else:
            seasons_chosen.append(seasons[choice_season - 1])

    return list(set(seasons_chosen))

def create_effects(scenario, factions_names):
    print("\n------ Rajouter un effet ------")
    choice = 1
    effects = dict()
    while choice == 1:
        print("\nQue voulez-vous rajouter : ")
        print("\t1. Effet global")
        print("\t2. Effet partisans")
        print("\t3. Effet satisfaction")
        print("\t0. Retour...")
        choice_effect = prevent_int("Réponse : ")
        while not (0 <= choice_effect < 4):
            choice_effect = prevent_int("\tMauvaise réponse\nRéponse : ")
        if choice_effect == 0:
            break
        else:
            if choice_effect == 1:
                list_effect_type = ["treasury", "agriculture", "industry"]
                print("\n[GLOBAL]\nQue voulez-vous rajouter : ")
                print("\t1. Trésorerie")
                print("\t2. Agriculture")
                print("\t3. Industrie")
                print("\t0. Retour...")
                choice_effect_type = prevent_int("Réponse : ")
                while not (0 <= choice_effect_type < 4):
                    choice_effect_type = prevent_int("\tMauvaise réponse\nRéponse : ")
                if choice_effect_type == 0:
                    continue
                else:
                    if "global" not in effects.keys():
                        effects["global"] = dict()
                    effects["global"][list_effect_type[choice_effect_type - 1]] = prevent_int("Valeur " + list_effect_type[choice_effect_type - 1] + " : ")
            elif choice_effect == 2:
                print("\n[PARTISANS]\nPour quelle faction : ")
                for i in range(len(factions_names)):
                    print("\t", i + 1, ". ", factions_names[i])
                print("\t0. Retour...")
                choice_faction = prevent_int("Réponse : ")
                while not (0 <= choice_faction <= len(factions_names)):
                    choice_faction = prevent_int("\tMauvaise réponse\nRéponse : ")
                if choice_faction == 0:
                    continue
                else:
                    if "supporter" not in effects.keys():
                        effects["supporter"] = dict()
                    effects["supporter"][factions_names[choice_faction - 1]] = prevent_int("Valeur partisans " + factions_names[choice_faction - 1] + " : ")
            elif choice_effect == 3:
                print("\n[SATISFACTION]\nPour quelle faction : ")
                for i in range(len(factions_names)):
                    print("\t", i + 1, ". ", factions_names[i])
                print("\t0. Retour...")
                choice_faction = prevent_int("Réponse : ")
                while not (0 <= choice_faction <= len(factions_names)):
                    choice_faction = prevent_int("\tMauvaise réponse\nRéponse : ")
                if choice_faction == 0:
                    continue
                else:
                    if "satisfaction" not in effects.keys():
                        effects["satisfaction"] = dict()
                    effects["satisfaction"][factions_names[choice_faction - 1]] = prevent_int("Valeur partisans " + factions_names[choice_faction - 1] + " : ")
        
        # save_scenario(scenario)
        choice = prevent_int("\n\nRajouter un autre effet ? (1 si oui) : ")
    
    return dict(effects)

def create_answer(scenario):
    print("\n------ Rajouter une réponse ------")
    choice = 1
    answers = []
    while choice == 1:

        answer = {
            "name": input("Réponse : "),
            "effects": create_effects(scenario, [faction["factionName"] for faction in scenario["factions"]]),
            "events": [],
            "vsevents": [],
            "vseffects": dict()
        }

        while prevent_int("Rajouter des events de réponse ? (1 si oui) : ") == 1:
            answer["events"].append(create_event(scenario, True))
        
        if prevent_int("Rajouter des effets de réponse ? (1 si oui) : ") == 1:
            answer["vseffects"] = create_effects(scenario)

        while prevent_int("Rajouter des events VS de réponse ? (1 si oui) : ") == 1:
            answer["vsevents"].append(create_event(scenario, False))
        
        # save_scenario(scenario)
        answers.append(answer)
        choice = prevent_int("\n\nRajouter une autre réponse ? (1 si oui) : ")

    return list(answers)

def create_event(scenario, son):
    print("\n------ Rajouter un event ------")
    when = 0
    if son:
        when = prevent_int("\nQuand s'effectuera-t-il ? (en nbre de tours) : ")

    event = {
        "title": input("Question : "),
        "seasons": choose_season(),
        "answers": create_answer(scenario),
        "father": True,
        "son": son,
        "when": when
    }

    if prevent_int("Event impossible en aléatoire ? (1 si oui) : ") == 1:
        event["father"] = False

    return dict(event)

def create_scenario(name):
    print("\n------ Création d'un scénario ------")
    scenario = {
        "scenarioTitle": name,
        "factions": [],
        "Events": []
    }

    save_scenario(scenario)

    choice = 1
    while choice == 1:        
        scenario["factions"].append(create_faction())
        save_scenario(scenario)
        choice = prevent_int("\n\nRajouter une autre faction ? (1 si oui) : ")

    choice = 1
    while choice == 1:
        scenario["Events"].append(create_event(scenario, False))
        save_scenario(scenario)
        choice = prevent_int("\n\nRajouter un autre event ? (1 si oui) : ")

    return dict(scenario)

def change_scenario(scenario):
    print("\n------ Modifier un scénario ------")
    choice = prevent_int("\n\nRajouter une autre faction ? (1 si oui) : ")
    while choice == 1:
        scenario["factions"].append(create_faction())
        choice = prevent_int("\n\nRajouter une autre faction ? (1 si oui) : ")

    save_scenario(scenario)

    choice = prevent_int("\n\nRajouter un autre event ? (1 si oui) : ")
    while choice == 1:
        scenario["Events"].append(create_event(scenario, False))
        choice = prevent_int("\n\nRajouter un autre event ? (1 si oui) : ")

def save_scenario(scenario):
    with open("scenario/" + scenario["scenarioTitle"] + ".json", "w") as file:
        json.dump(scenario, file)
    
    print("\n\t:::::Sauvegardé:::::")

def prevent_int(string_value):
    while True:
        try:
            string_input = input(string_value)
            if string_input == "":
                return 0
            result = int(string_input)
            return result
        except:
            print("\tMauvaise réponse : il faut un entier.")



if __name__ == "__main__":

    choice = -1

    print("\n ╔═══════════════════════════════════════════════════════════════════════════════════════════════════╗\n"+
          " ║    ____                _                         _                                       _        ║\n"+
          " ║   / ___|_ __ ___  __ _| |_ ___ _   _ _ __     __| | ___    ___  ___ ___ _ __   __ _ _ __(_) ___   ║\n"+
          " ║  | |   | '__/ _ \/ _` | __/ _ \ | | | '__|   / _` |/ _ \  / __|/ __/ _ \ '_ \ / _` | '__| |/ _ \  ║\n"+
          " ║  | |___| | |  __/ (_| | ||  __/ |_| | |     | (_| |  __/  \__ \ (_|  __/ | | | (_| | |  | | (_) | ║\n"+
          " ║   \____|_|  \___|\__,_|\__\___|\__,_|_|      \__,_|\___|  |___/\___\___|_| |_|\__,_|_|  |_|\___/  ║\n"+
          " ║                                                                                                   ║\n"+
          " ╚═══════════════════════════════════════════════════════════════════════════════════════════════════╝\n")

    print("\n\t1. Créer un scénario")
    print("\t2. Charger un scénario")
    print("\t0. Quitter")
    choice = prevent_int("Réponse : ")
    while not (0 <= choice < 3):
        choice = prevent_int("\tMauvaise réponse\nRéponse : ")

    if choice == 1:
        
        name = input("Nom sénario : ")
        scenario = create_scenario(name)

        with open("scenario/" + scenario["scenarioTitle"] + ".json", "w") as file:
            json.dump(scenario, file)
        
        print(json.dumps(scenario))

    elif choice == 2:

        name = input("Nom du fichier : ")
        while not path.exists("scenario/" + name + ".json"):
            name = input("\tLe fichier" + name + ".json n'existe pas.\nNom du fichier : ")

        scenario = None
        with open("scenario/" + name + ".json") as file:
            scenario = json.load(file)

        change_scenario(scenario)

        with open("scenario/" + name + ".json", "w") as file:
            json.dump(scenario, file)
        
        print(json.dumps(scenario))
    
    input("\nBye!")

    

